package data_structures;

import java.util.Iterator;

/**
 * A list of data.
 * 
 * The list interface, ListI, describes the interface that must
 * be implemented by lists conforming to this interface. This interface
 * does not explicitly say how you must implement these methods.
 * 
 * This interface provides stipulations on what you must implement,
 * and what they are called. The interface includes methods
 * for adding and removing elements. Efficient methods should be 
 * provided for determining if the list is empty, and for 
 * determining the current size of the list. Methods for determining
 * whether the list is full will depend on the implementation, but
 * should be efficiently encoded.
 * 
 * @author Brandon Castro
 * @param <E> the type of elements in the Stack
 */

public class Stack<E> {
	private ListI list;

	public Stack() {
		list = new LinkedList<>();
	}

	public void push(E obj) {
		list.
	}

	public E pop() {
	}

	public int size() {
	}

	public boolean isEmpty() {
	}

	public boolean isFull() {
	}

	public E peek() {
	}

	public boolean contains(E obj) {
	}

	public void makeEmpty() {
	}

	public Iterator iterator() {
	}
}
