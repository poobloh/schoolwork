package data_structures;

import java.util.Iterator;

import javax.xml.soap.Node;

/**
 * A linked list of data.
 * 
 * This is a linked list implementation of the ListI interface 
 * 
 * The linked list interface, ListI, describes the interface that must
 * be implemented by lists conforming to this interface. This interface
 * does not explicitly say how you must implement these methods.
 * 
 * This interface provides stipulations on what you must implement,
 * and what they are called. The interface includes methods
 * for adding and removing elements. Efficient methods should be 
 * provided for determining if the list is empty, and for 
 * determining the current size of the list. Methods for determining
 * whether the list is full will depend on the implementation, but
 * should be efficiently encoded.
 * 
 * @author Brandon Castro
 * @param <E> the type of elements in this Linked List
 */

public class LinkedList<E> implements ListI<E> {
	
// Private variables
	private head 
	private next = NULL;
	private currentSize = 0;

	/* (non-Javadoc)
	 * @see data_structures.ListI#addFirst(java.lang.Object)
	 */
	@Override
	public void addFirst(E obj) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see data_structures.ListI#addLast(java.lang.Object)
	 */
	@Override
	public void addLast(E obj) {
		// TODO Auto-generated method stub
		
	}

	/* (non-Javadoc)
	 * @see data_structures.ListI#removeFirst()
	 */
	@Override
	public E removeFirst() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see data_structures.ListI#removeLast()
	 */
	@Override
	public E removeLast() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see data_structures.ListI#peekFirst()
	 */
	@Override
	public E peekFirst() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see data_structures.ListI#peekLast()
	 */
	@Override
	public E peekLast() {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see data_structures.ListI#makeEmpty()
	 */
	@Override
	public void makeEmpty() {
		tail = head = null;
		currentSize = 0;		
	}

	/* (non-Javadoc)
	 * @see data_structures.ListI#isEmpty()
	 */
	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * LinkedList will use maximum possible memory 
	 * @return false
	 */
	@Override
	public boolean isFull() {
		return false;
	}

	/**
	 * 
	 * @returns int
	 */
	@Override
	public int size() {
		return currentSize;
	}

	/* (non-Javadoc)
	 * @see data_structures.ListI#iterator()
	 */
	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	public E remove(E obj) {
		Node<E> current = head, 
				previous = null;
		
		// when current becomes null 
		while(current != null) { //NOT CURRENT.NEXT
			if(((Comparable<e>) obj).compareTo(current.data) == 0 ) {
				if (current == head)
					return removeFirst();
				if(current == tail)
					return removeLast();
				
				previous.next = current.next;
				currentSize--;
				return current.data;
			}
			
			previous = current;
			current = current.next
		}
		
		return null;
	}
	
	public boolean contains(E obj) {
		Node<E> current = head;
		
		while(current != null) {
			if( ((Comparable<E>) obj).compareTo(current.data)) == 0) {
				
				//......
				
				return true;
			}
			previous = current; // ? 
			current = current.next; // ?
		}
	}
}
